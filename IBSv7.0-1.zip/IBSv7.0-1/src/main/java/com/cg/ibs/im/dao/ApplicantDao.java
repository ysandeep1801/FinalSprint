package com.cg.ibs.im.dao;

import java.util.Set;

import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.ApplicantStatus;
import com.cg.ibs.im.exception.IBSCustomException;

public interface ApplicantDao {
	
	Long saveApplicant(Applicant applicant) throws IBSCustomException;
	
	Set<Long> getAllApplicants() throws IBSCustomException;
	
	Applicant getApplicantDetails(long applicantId) throws IBSCustomException;
	
	Set<Applicant> getApplicantsByStatus(ApplicantStatus applicantStatus) throws IBSCustomException;

	boolean isApplicantPresent(long applicantId) throws IBSCustomException;

	boolean updateApplicant(Applicant applicant) throws IBSCustomException;
	
}
