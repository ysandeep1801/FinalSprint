package com.cg.ibs.im.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.im.dao.AccountDao;
import com.cg.ibs.im.dao.ApplicantDao;
import com.cg.ibs.im.dao.BankerDao;
import com.cg.ibs.im.dao.CustomerDao;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.Account;
import com.cg.ibs.im.model.AccountHolding;
import com.cg.ibs.im.model.AccountHoldingType;
import com.cg.ibs.im.model.AccountStatus;
import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.ApplicantStatus;
import com.cg.ibs.im.model.Customer;


@Service("bankerService")
public class BankerServiceImpl implements BankerService {

	@Autowired
	private BankerDao bankerDao;
	@Autowired
	private ApplicantDao applicantDao;
	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private AccountDao accountDao;
	
	private static Logger LOGGER = Logger.getLogger(BankerServiceImpl.class);
	


	@Override
	public boolean verifyBankerLogin(String user, String password) throws IBSCustomException {
		LOGGER.info("In verifyBankerLogin method");
		boolean result = false;
		result = bankerDao.checkBankerLogin(user, password);
		return result;
	}

	@Override
	public Set<Applicant> viewPendingApplications() throws IBSCustomException {
		LOGGER.info("In viewPendingApplications method");

		return applicantDao.getApplicantsByStatus(ApplicantStatus.PENDING);
	}

	@Override
	public Set<Applicant> viewApprovedApplications() throws IBSCustomException {
		LOGGER.info("In viewApprovedApplications method");

		return applicantDao.getApplicantsByStatus(ApplicantStatus.APPROVED);
	}

	@Override
	public Set<Applicant> viewDeniedApplications() throws IBSCustomException {
		LOGGER.info("In viewDeniedApplications method");

		return applicantDao.getApplicantsByStatus(ApplicantStatus.DENIED);
	}

	@Override
	public String generatePassword(long applicantId) {
		LOGGER.info("In generatePassword method");

		String alphaNumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
		StringBuilder stringBuffer = new StringBuilder(8);

		for (int i = 0; i < 8; i++) {
			int index = (int) (alphaNumeric.length() * Math.random());
			stringBuffer.append(alphaNumeric.charAt(index));
		}
		return stringBuffer.toString();
	}

	@Override
	public boolean isApplicantPresentInPendingList(long applicantId) throws IBSCustomException {
		LOGGER.info("In isApplicantPresentInPendingList method");

		boolean result = false;
		if (applicantId != 0) {
			LOGGER.debug("applicantId is not zero");

			Set<Applicant> pendingApplicants = applicantDao.getApplicantsByStatus(ApplicantStatus.PENDING);
			Iterator<Applicant> it = pendingApplicants.iterator();
			while (it.hasNext()) {
				if (it.next().getApplicantId() == applicantId) {
					result = true;
					break;
				}
			}
		}
		return result;
	}

	@Override
	public boolean isApplicantPresent(long applicantId) throws IBSCustomException {
		return applicantDao.isApplicantPresent(applicantId);
	}

	@Override
	public Applicant displayDetails(long applicantId) throws IBSCustomException {
		
		Applicant applicant = applicantDao.getApplicantDetails(applicantId);
		
		return applicant;
	}

	@Override
	public String generateUsername(long applicantId) throws IBSCustomException {
		Applicant applicant = new Applicant();
		applicant = applicantDao.getApplicantDetails(applicantId);

		String username = applicant.getFirstName().charAt(0) + applicant.getLastName();
		if (username.length() > 12) {
			username = username.substring(0, 10);
		}
		int index = 1;
		while (!checkUsernameIsUnique(username)) {
			username = username.concat(String.valueOf(index));
			if (username.length() > 15) {
				username = username.substring(0, 14);
			}
			index++;
		}
		return username;
	}

	public boolean checkUsernameIsUnique(String username) {
		boolean result = true;
		try {
			if (customerDao.checkCustomerByUsernameExists(username)) {
				result = false;
			}
		} catch (Exception exception) {
			exception.getMessage();
		}
		return result;
	}

	@Override
	public boolean download(Applicant applicant) throws IBSCustomException {
		boolean result = false;
		byte[] aadhar = applicant.getAadharDocument();
		byte[] pan = applicant.getPanDocument();
		File dir = new File("./downloads");
		if (!dir.exists()) {
			dir.mkdir();
		}
		try (FileOutputStream outputStream1 = new FileOutputStream(
				dir.getPath() + "/" + applicant.getApplicantId() + "aadhar.pdf");
				FileOutputStream outputStream2 = new FileOutputStream(
						dir.getPath() + "/" + applicant.getApplicantId() + "pan.pdf")) {
			outputStream1.write(aadhar);
			outputStream1.flush();
			outputStream1.close();
			outputStream2.write(pan);
			outputStream2.flush();
			outputStream2.close();
			result = true;
		} catch (FileNotFoundException e) {
			e.getMessage();
		} catch (IOException e) {
			e.getMessage();
		}
		return result;

	}

	@Transactional
	@Override
	public Customer createNewCustomer(Applicant applicant) throws IBSCustomException {
		Customer customer = new Customer();
		try {
			customer = saveNewCustomer(applicant);
			
			AccountHolding ah = new AccountHolding();
			//INDIVIDUAL ACCOUNT
			if (applicant.getLinkedApplication().equals(new Long(0))) {
				Account account = new Account();
				AccountHoldingType aHType = AccountHoldingType.INDIVIDUAL;
				account = new Account();
				account.setBalance(new BigDecimal(0));
				account.setTrans_Pwd("password");
				account.setAccCreationDate(LocalDate.now());
				account.setOpenBalance(new BigDecimal(0));
				account.setAccStatus(AccountStatus.ACTIVE);

				account.setAccType(AccountType.SAVINGS);
				ah.setCustomer(customer);
				ah.setAccount(account);
				ah.setType(aHType);
				Set<AccountHolding> ahSet = Collections.singleton(ah);
				account.setAccountHoldings(ahSet);
				customer.setAccountHoldings(ahSet);

				accountDao.saveAccount(account);

			} else if (applicant.getLinkedApplication().equals(new Long(555))) {
				// set account holdings accordingly
				//JOINT ACCOUNT SECONDARY 
			} else {
				//JOINT ACCOUNT PRIMARY
				
				Account account = new Account();
				account.setBalance(new BigDecimal(0));
				account.setTrans_Pwd("password");
				account.setAccCreationDate(LocalDate.now());
				account.setOpenBalance(new BigDecimal(0));
				account.setAccStatus(AccountStatus.ACTIVE);
				account.setAccType(AccountType.JOINT_SAVINGS);
								
				Long appId = customer.getApplicantId();
				Long linkedAppId = applicantDao.getApplicantDetails(appId).getLinkedApplication();
				Applicant applicant1 = applicantDao.getApplicantDetails(linkedAppId);
				applicant1.setApplicantStatus(ApplicantStatus.APPROVED);				
				applicantDao.updateApplicant(applicant1);
				
				Customer customer1 = saveNewCustomer(applicant1);
				
				ah = new AccountHolding();
				ah.setCustomer(customer);
				ah.setAccount(account);
				ah.setType(AccountHoldingType.PRIMARY);

				AccountHolding ah2 = new AccountHolding();
				ah2.setAccount(account);
				ah2.setCustomer(customer1);
				ah2.setType(AccountHoldingType.SECONDARY);

				Set<AccountHolding> ahSet = new HashSet<AccountHolding>();
				ahSet.add(ah);
				ahSet.add(ah2);
				account.setAccountHoldings(ahSet);
				
				customer.setAccountHoldings(Collections.singleton(ah));
				customer1.setAccountHoldings(Collections.singleton(ah2));
				
				accountDao.saveAccount(account);				
			}

			// create the account for that customer
			// from application
		} catch (Exception exception) {
			exception.getMessage();
		}

		return customer;
	}
	
	public Customer saveNewCustomer(Applicant applicant) throws IBSCustomException {

		Customer customer = new Customer();
		Long applicantId = applicant.getApplicantId();
		String userId = generateUsername(applicantId);
		customer.setUserId(userId);
		customer.setPassword(generatePassword(applicantId));
		customer.setApplicantId(applicantId);
		customer.setFirstName(applicant.getFirstName());
		customer.setLastname(applicant.getLastName());
		customer.setFatherName(applicant.getFatherName());
		customer.setMotherName(applicant.getMotherName());
		customer.setDateofBirth(applicant.getDob());
		customer.setGender(applicant.getGender());
		customer.setMobileNumber(applicant.getMobileNumber());
		customer.setAlternateMobileNumber(applicant.getAlternateMobileNumber());
		customer.setEmailId(applicant.getEmailId());
		customer.setAadharNumber(applicant.getAadharNumber());
		customer.setPanNumber(applicant.getPanNumber());
		customer.setLogin(new Integer(0));
		customer.setAddress(applicant.getAddress());
		customerDao.saveCustomer(customer);
		return customer;
	}

	@Transactional
	@Override
	public boolean updateCustomer(Customer customer) throws IBSCustomException {
		boolean result = false;
		result = customerDao.updateCustomer(customer);
		return result;
	}

}
