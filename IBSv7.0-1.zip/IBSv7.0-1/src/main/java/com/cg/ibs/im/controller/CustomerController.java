package com.cg.ibs.im.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.ApplicantStatus;
import com.cg.ibs.im.model.Customer;
import com.cg.ibs.im.service.CustomerService;

@RestController
@RequestMapping("/customer")
@Scope("session")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	private Customer cust;

	@PostMapping("/login")
	public ResponseEntity<String> customerLogin(@RequestBody Customer customer) {
		ResponseEntity<String> result;

		try {
			if (customer.getUserId() == null || customer.getUserId().equals("")) {
				result = new ResponseEntity<>("No user details found", HttpStatus.BAD_REQUEST);
			} else {
				try {
					if (customerService.login(customer.getUserId(), customer.getPassword())) {
						cust = customerService.getCustomerDetails(customer.getUserId());
						result = new ResponseEntity<>("Welcome " + cust.getFirstName() + " " + cust.getLastname(), HttpStatus.OK);
					} else {
						result = new ResponseEntity<>("Unauthorised User - INCORRECT USERNAME/PASSWORD",
								HttpStatus.UNAUTHORIZED);
					}
				} catch (IBSCustomException exception) {
					result = new ResponseEntity<>("Unauthorised User  - INCORRECT USERNAME/PASSWORD",
							HttpStatus.UNAUTHORIZED);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			result = new ResponseEntity<>("Internal Issue", HttpStatus.BAD_REQUEST);
		}

		return result;
	}

	@PostMapping("/registered/individual")
	public ResponseEntity<String> signUp(@RequestBody Applicant applicant) {
		ResponseEntity<String> result;
		try {
			applicant.setApplicationDate(LocalDate.now());
			applicant.setLinkedApplication(new Long(0));
			applicant.setExistingCustomer(false);
			applicant.setRemarks("none");
			applicant.setApplicantStatus(ApplicantStatus.PENDING);
			applicant.setAccountType(AccountType.SAVINGS);
			Long applicantId = customerService.saveApplicantDetails(applicant);
			result = new ResponseEntity<String>(
					"Registered successfully.Your applicant id is " + applicant.getApplicantId(), HttpStatus.OK);

		} catch (IBSCustomException e) {
			result = new ResponseEntity<String>("Registration failed", HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}
		return result;
	}

	@PostMapping("/registered/joint")
	public ResponseEntity<String> signUp(@RequestBody Applicant[] applicant) {
		ResponseEntity<String> result = null;

		try {
			applicant[0].setApplicationDate(LocalDate.now());
			applicant[0].setLinkedApplication(new Long(0));
			applicant[0].setExistingCustomer(false);
			applicant[0].setRemarks("none");
			applicant[0].setApplicantStatus(ApplicantStatus.PENDING);
			applicant[0].setAccountType(AccountType.JOINT_SAVINGS);
			Long applicantId = customerService.saveApplicantDetails(applicant[0]);
			applicant[1].setApplicationDate(LocalDate.now());
			applicant[1].setLinkedApplication(new Long(555));
			applicant[1].setExistingCustomer(false);
			applicant[1].setRemarks("none");
			applicant[1].setApplicantStatus(ApplicantStatus.PENDING);
			applicant[1].setAccountType(AccountType.JOINT_SAVINGS);
			Long applicantId1 = customerService.saveApplicantDetails(applicant[1]);
			applicant[0].setLinkedApplication(applicantId1);
			customerService.updateApplicant(applicant[0]);
			result = new ResponseEntity<String>(
					"Registered successfully.\nApplicant id for primary customer is " + applicantId, HttpStatus.OK);

		} catch (IBSCustomException e) {
			result = new ResponseEntity<String>("Registration failed", HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}

		return result;

	}

	@PostMapping(value = "/checkStatus/{applicantId}")
	public ResponseEntity<String> applicantStatus(@PathVariable("applicantId") Long applicantId) {
		ResponseEntity<String> result;
		String message;
		try {
			String id = applicantId.toString();
			Applicant applicant1 = customerService.getApplicantDetails(applicantId);
			String accountType = applicant1.getAccountType().toString();
			message = customerService.checkStatus(applicantId).toString();
			if (message == null) {
				result = new ResponseEntity<String>("Status couldn't be updated", HttpStatus.BAD_REQUEST);
			} else if (message.equals("APPROVED")) {
				Customer customer = customerService.getCustomerByApplicantId(applicantId);
				if (applicant1.getAccountType() == AccountType.SAVINGS) {
					message = "Your application has been APPROVED. User ID: " + customer.getUserId() + ", Password: "
							+ customer.getPassword() + ", UCI: " + customer.getUci();
					result = new ResponseEntity<String>(message, HttpStatus.OK);
				} else {
					Long linkedApplicant = applicant1.getLinkedApplication();
					Customer customer2 = customerService.getCustomerByApplicantId(linkedApplicant);
					message = "Your application has been APPROVED. User ID: " + customer.getUserId() + ", Password: "
							+ customer.getPassword() + ", UCI: " + customer.getUci() + ", SECONDARY CUSTOMER: User ID: "
							+ customer2.getUserId() + ", Password: " + customer2.getPassword() + ", UCI: "
							+ customer2.getUci();
					result = new ResponseEntity<String>(message, HttpStatus.OK);
				}
			} else if (message.equals("DENIED")) {
				result = new ResponseEntity<String>(
						"Application has been DENIED. Remarks by banker: " + applicant1.getRemarks(), HttpStatus.OK);
			} else {
				result = new ResponseEntity<String>("Application status is PENDING", HttpStatus.OK);
			}
		} catch (IBSCustomException exception) {
			result = new ResponseEntity<String>("Applicant ID is invalid", HttpStatus.BAD_REQUEST);
		}
		return result;
	}

	@PostMapping(value = "/updatePassword/{password1}/{password2}")
	public ResponseEntity<String> updateCustomerPassword(@PathVariable("password1") String password1,
			@PathVariable("password2") String password2) {
		ResponseEntity<String> result;
		try {
			if (password1.equals("") || password2.equals("")) {
				result = new ResponseEntity<String>("REQUIRED FIELDS can't be left empty", HttpStatus.UNAUTHORIZED);
			} else if (!customerService.checkCustomerDetails(password1, password2)) {
				result = new ResponseEntity<String>("Passwords don't match. Update failed", HttpStatus.UNAUTHORIZED);
			} else {
				if (cust.getLogin() == 0) {
					cust.setPassword(password1);
					if (customerService.updateCustomer(cust)) {
						result = new ResponseEntity<String>("Welcome " + cust.getFirstName() + " " + cust.getLastname(),
								HttpStatus.OK);
					} else {
						result = new ResponseEntity<String>("Password Updation failed", HttpStatus.BAD_REQUEST);
					}
				} else {
					result = new ResponseEntity<String>("Password Updation failed, not your first Login",
							HttpStatus.BAD_REQUEST);
				}
			}
		} catch (IBSCustomException exception) {
			result = new ResponseEntity<String>("Password Updation failed", HttpStatus.UNAUTHORIZED);
			exception.printStackTrace();
		}
		return result;
	}

}
