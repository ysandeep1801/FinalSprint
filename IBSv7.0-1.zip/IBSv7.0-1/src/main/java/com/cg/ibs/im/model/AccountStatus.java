package com.cg.ibs.im.model;

public enum AccountStatus {
	ACTIVE, CLOSED;
}
