package com.cg.ibs.im.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.im.model.AccountHolding;
import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.ApplicantStatus;
import com.cg.ibs.im.model.BankAdmins;
import com.cg.ibs.im.model.Customer;
import com.cg.ibs.im.service.BankerService;
import com.cg.ibs.im.service.CustomerService;

@RestController
@RequestMapping("/bank")
public class BankController {

	@Autowired
	private BankerService bankerService;

	@Autowired
	private CustomerService customerService;

	@PostMapping("/login")
	public ResponseEntity<String> bankerLogin(@RequestBody BankAdmins bankAdmin) {
		ResponseEntity<String> responseEntity;
		try {
			if (bankAdmin.getAdminId() == null || bankAdmin.getAdminId().equals("")) {
				responseEntity = new ResponseEntity<String>("No user details found", HttpStatus.BAD_REQUEST);
			} else if (bankerService.verifyBankerLogin(bankAdmin.getAdminId(), bankAdmin.getPassword())) {
				responseEntity = new ResponseEntity<String>("Welcome Banker, " + bankAdmin.getAdminId(), HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<String>("INCORRECT USERNAME/PASSWORD", HttpStatus.UNAUTHORIZED);
			}
		} catch (Exception exception) {
			responseEntity = new ResponseEntity<String>("Internal Error", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping("/pending")
	public ResponseEntity<Set<Long>> viewPendingRequests() {
		ResponseEntity<Set<Long>> responseEntity;
		try {
			Set<Long> pendingApplicants = new HashSet<Long>();
			Set<Applicant> pa = bankerService.viewPendingApplications();
			if(pa.size()!=0) {
				for(Applicant a: pa) {
					if(a.getLinkedApplication()!=555) {
						pendingApplicants.add(a.getApplicantId());
					}
				}
			}
			responseEntity = new ResponseEntity<Set<Long>>(pendingApplicants, HttpStatus.OK);
		} catch(Exception exception) {
			exception.printStackTrace();
			Set<Long> pendingApplicants = new HashSet<Long>();
			responseEntity = new ResponseEntity<Set<Long>>(pendingApplicants, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@GetMapping("/approved")
	public ResponseEntity<Set<Long>> viewApprovedRequests() {
		ResponseEntity<Set<Long>> responseEntity;
		try {
			Set<Long> approvedApplicants = new HashSet<Long>();
			Set<Applicant> aa = bankerService.viewApprovedApplications();
			if(aa.size()!=0) {
				for(Applicant a:aa) {
					if(a.getLinkedApplication()!=555) {
						approvedApplicants.add(a.getApplicantId());
					}
				}
			}
			responseEntity = new ResponseEntity<Set<Long>>(approvedApplicants, HttpStatus.OK);
		} catch(Exception exception) {
			exception.printStackTrace();
			Set<Long> approvedApplicants = new HashSet<Long>();
			responseEntity = new ResponseEntity<Set<Long>>(approvedApplicants, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@GetMapping("/denied")
	public ResponseEntity<Set<Long>> viewDeniedRequests() {
		ResponseEntity<Set<Long>> responseEntity;
		try {
			Set<Long> deniedApplicants = new HashSet<Long>();
			Set<Applicant> da = bankerService.viewDeniedApplications();
			if(da.size()!=0) {
				for(Applicant a:da) {
					if(a.getLinkedApplication()!=555) {
						deniedApplicants.add(a.getApplicantId());
					}
				}
			}
			responseEntity = new ResponseEntity<Set<Long>>(deniedApplicants, HttpStatus.OK);
		} catch(Exception exception) {
			exception.printStackTrace();
			Set<Long> deniedApplicants = new HashSet<Long>();
			responseEntity = new ResponseEntity<Set<Long>>(deniedApplicants, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@RequestMapping("/applicantDetails/{applicantId}")
	public ResponseEntity<String> viewApplicantDetails(@PathVariable("applicantId") Long applicantId) {
		ResponseEntity<String> responseEntity;
		try {
			Applicant applicant = bankerService.displayDetails(applicantId);
			applicant.setAadharDocument(null);
			applicant.setPanDocument(null);
			String result = applicant.toString();
			
			if(applicant.getLinkedApplication()!=(555) && applicant.getLinkedApplication()!=(0)) {
				Applicant secApplicant = bankerService.displayDetails(applicant.getLinkedApplication());
				secApplicant.setAadharDocument(null);
				secApplicant.setPanDocument(null);
				result = result + "\n\n"+ "--------------------"
						+ "------------------------------\n\n" + secApplicant.toString();
			}
			responseEntity = new ResponseEntity<String>(result, HttpStatus.OK);
			
		} catch (Exception exception) {
			exception.printStackTrace();
			responseEntity = new ResponseEntity<String>("Applicant Not found", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@PostMapping("/approve/{applicantId}")
	public ResponseEntity<String> approveApplicant(@PathVariable("applicantId") Long applicantId) {
		ResponseEntity<String> responseEntity;
		
		try {
			Applicant applicantBean = bankerService.displayDetails(applicantId);
			if(applicantBean.getApplicantStatus()==ApplicantStatus.PENDING) {
				applicantBean.setApplicantStatus(ApplicantStatus.APPROVED);
				if(applicantBean.getAccountType()==AccountType.SAVINGS) {
					Customer customer = bankerService.createNewCustomer(applicantBean);
					Set<AccountHolding> ahb = customer.getAccountHoldings();
					AccountHolding customerHoldings = new AccountHolding();
					for(AccountHolding ah : ahb) {
						customerHoldings = ah;
					}
					String result = "APPROVED-----UCI: "+ customer.getUci().toString()+"-------User Id: "+customer.getUserId() +"---------Account Number: "+ customerHoldings.getAccount().getAccNo().toString();
					responseEntity = new ResponseEntity<String>(result, HttpStatus.OK);
				} else {
					Customer customer = bankerService.createNewCustomer(applicantBean);
					Set<AccountHolding> ahb = customer.getAccountHoldings();
					AccountHolding customerHoldings = new AccountHolding();
					for(AccountHolding ah : ahb) {
						customerHoldings = ah;
					}
					Applicant linkedApplicant = customerService.getApplicantDetails(applicantBean.getLinkedApplication());
					Customer secCustomer = bankerService.createNewCustomer(linkedApplicant);
					String result = "APPROVED-----UCI: "+ customer.getUci().toString()+"-------User Id: "+customer.getUserId()+"----SECONDARY CUSTOMER: UCI:" + secCustomer.getUci().toString()+"-------user id: " + secCustomer.getUserId() +"---------Account Number: "+ customerHoldings.getAccount().getAccNo().toString()+ "********here***************";
					responseEntity = new ResponseEntity<String>(result, HttpStatus.OK);
				}
			} else {
				responseEntity = new ResponseEntity<String>("Application doesn't exist in pending list, you can't approve it.", HttpStatus.BAD_REQUEST);
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			responseEntity = new ResponseEntity<String>("Couldn't process successfully", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return responseEntity;
	}
	
	@PostMapping("/deny/{applicantId}")
	public ResponseEntity<String> denyApplicant(@PathVariable("applicantId") Long applicantId, @RequestParam("remarks") String remarks) {
		ResponseEntity<String> responseEntity;
		try {
			Applicant applicantBean = bankerService.displayDetails(applicantId);
			if(applicantBean.getApplicantStatus()==ApplicantStatus.PENDING) {
				applicantBean.setApplicantStatus(ApplicantStatus.DENIED);
				applicantBean.setRemarks(remarks);
				customerService.updateApplicant(applicantBean);
				responseEntity = new ResponseEntity<String>("Application Denied, Remarks: "+remarks, HttpStatus.OK);
			} else {
				responseEntity = new ResponseEntity<String>("Application doesn't exist in pending list, you can't deny it.", HttpStatus.BAD_REQUEST);
			}
						
		} catch (Exception exception) {
			exception.printStackTrace();
			responseEntity = new ResponseEntity<String>("Couldn't process successfully", HttpStatus.INTERNAL_SERVER_ERROR);
		}
 		return responseEntity;
	}
	
	
//	@GetMapping("/abc")
//	public String banker() {
//		return "hello";
//	}

//	@PutMapping(value = "/updateStatus/{applicantId}")
//	public ResponseEntity<String> updateStatus(@PathVariable("applicantId") Long applicantId, @RequestParam("action") String action) {
//		ResponseEntity<String> responseEntity;
//		ApplicantBean applicant = new ApplicantBean();
//		try {
//			applicant = customerService.getApplicantDetails(applicantId);
//
//			if (action.equals("APPROVED")) {
//
//				applicant.setApplicantStatus(ApplicantStatus.APPROVED);
//				customerService.updateApplicant(applicant);
//				CustomerBean customer = bankerService.createNewCustomer(applicant);
//				responseEntity = new ResponseEntity<String>(
//						"Application approved and customer created: " + customer.getUci().toString(), HttpStatus.OK);
//			} else if (action.equals("DENIED")) {
//				applicant.setApplicantStatus(ApplicantStatus.APPROVED);
//				customerService.updateApplicant(applicant);
//				responseEntity = new ResponseEntity<String>("Application denied", HttpStatus.OK);
//			} else {
//				responseEntity = new ResponseEntity<String>("No updates", HttpStatus.OK);
//			}
//		} catch (Exception exception) {
//			responseEntity = new ResponseEntity<String>("INTERNAL ERROR", HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//		return responseEntity;
//	}

//	@GetMapping("/deny")
//	public ResponseEntity<String> denyApplication()
//
//	@GetMapping("/getRequests/{type}")
//	public ResponseEntity<List<ApplicantBean>> getRequests(@RequestParam String type) {
//		ResponseEntity<List<ApplicantBean>> responseEntity;
//		try {
//			if (type == null) {
//				responseEntity = new ResponseEntity<>("Invalid request", HttpStatus.BAD_REQUEST);
//			} else if (type.equals("approved")) {
//				responseEntity = new ResponseEntity<List<ApplicantBean>>(bankerService.viewApprovedApplications(),
//						HttpStatus.OK);
//			} else {
//				responseEntity = new ResponseEntity<String>("INCORRECT USERNAME/PASSWORD", HttpStatus.UNAUTHORIZED);
//			}
//		} catch (Exception exception) {
//			exception.printStackTrace();
//			responseEntity = new ResponseEntity<String>("Internal Error", HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//		return responseEntity;
//	}

}
